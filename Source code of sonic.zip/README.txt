gcc�������ɶ�̬��speed_change.dll��gcc -o speed_change.dll -shared -fPIC runsonic.c sonic.c sonic.h��

Copyright (c) 2022 Qilu University of Technology, School of Computer Science & Technology, Duyu (No.202103180009).
Copyright (c) 2010 Bill Cox. (Sonic Library)
This file is licensed under the Apache 2.0 license.
